using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace CS4104.EditorTools
{
    /// <summary>
    /// Menu: CS4104 > Build Demo Scene.
    /// Creates an empty scene containing one GameObject with the CarDesignDemo
    /// component. Everything else (cameras, meshes, materials, UI) is generated
    /// procedurally when you press Play, so the demo works in both the Built-in
    /// Render Pipeline and URP without any imported art assets.
    /// Target editor: Unity 6000.3.22f1 (also works on 2022.3+).
    /// </summary>
    public static class DemoSceneBuilder
    {
        public const string ScenePath = "Assets/CS4104_CarDesignVR_Demo.unity";

        [MenuItem("CS4104/Build Demo Scene", false, 1)]
        public static void BuildScene()
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            CreateScene();
        }

        [MenuItem("CS4104/Build Demo Scene and Play", false, 2)]
        public static void BuildAndPlay()
        {
            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo()) return;
            CreateScene();
            EditorApplication.isPlaying = true;
        }

        /// <summary>Creates and saves the demo scene without asking questions.</summary>
        public static void CreateScene()
        {
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            var go = new GameObject("CS4104_CarDesignVR_Demo");
            go.AddComponent<CS4104.CarDesignDemo>();
            EditorSceneManager.SaveScene(scene, ScenePath);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            Selection.activeGameObject = go;
            Debug.Log("[CS4104] Demo scene ready at " + ScenePath + ". Press Play to run the demo.");
        }
    }
}
