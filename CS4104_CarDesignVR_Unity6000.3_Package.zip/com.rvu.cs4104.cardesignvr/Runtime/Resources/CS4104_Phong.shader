// CS4104 – Phong illumination shader used by every solid object in the demo.
// I = Ka*Ia*C + Kd*Il*C*max(N.L,0) + Ks*Il*max(R.V,0)^n   (per-pixel Phong)
// Extra teaching features controlled from C# through global properties:
//   _CS_DepthView  : show the Z-buffer (eye depth) instead of colour
//   _CS_ClipOn     : discard fragments in front of a section (clipping) plane
//   Cull [_Cull]   : Back / Off / Front -> back-face culling experiment
//   VFACE          : back faces are painted _BackColor (magenta) so they are visible
Shader "CS4104/Phong"
{
    Properties
    {
        _Color ("Base Colour", Color) = (0.8, 0.1, 0.1, 1)
        _BackColor ("Back-face Colour", Color) = (1, 0, 1, 1)
        _Ka ("Ambient Ka", Range(0,1)) = 0.25
        _Kd ("Diffuse Kd", Range(0,1)) = 0.8
        _Ks ("Specular Ks", Range(0,1)) = 0.5
        _Shininess ("Shininess n", Range(1,256)) = 48
        [Enum(UnityEngine.Rendering.CullMode)] _Cull ("Cull Mode", Float) = 2
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" "Queue"="Geometry" }
        Pass
        {
            Cull [_Cull]
            ZWrite On
            ZTest LEqual

            CGPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma target 3.0
            #include "UnityCG.cginc"

            float4 _Color;
            float4 _BackColor;
            float _Ka, _Kd, _Ks, _Shininess;

            float4 _CS_LightDir;     // world-space direction TOWARDS the light
            float4 _CS_LightColor;
            float4 _CS_Ambient;
            float  _CS_DepthView;
            float  _CS_Near;
            float  _CS_Far;
            float4 _CS_ClipPlane;    // xyz = plane normal, w = d ; keep n.p <= d
            float  _CS_ClipOn;

            struct appdata { float4 vertex : POSITION; float3 normal : NORMAL; };
            struct v2f
            {
                float4 pos      : SV_POSITION;
                float3 worldPos : TEXCOORD0;
                float3 worldN   : TEXCOORD1;
                float  eyeDepth : TEXCOORD2;
            };

            v2f vert (appdata v)
            {
                v2f o;
                o.pos = UnityObjectToClipPos(v.vertex);
                o.worldPos = mul(unity_ObjectToWorld, v.vertex).xyz;
                o.worldN = UnityObjectToWorldNormal(v.normal);
                o.eyeDepth = -UnityObjectToViewPos(v.vertex).z;   // distance along view axis
                return o;
            }

            float4 frag (v2f i, float facing : VFACE) : SV_Target
            {
                if (_CS_ClipOn > 0.5)
                    clip(_CS_ClipPlane.w - dot(i.worldPos, _CS_ClipPlane.xyz));

                if (_CS_DepthView > 0.5)
                {
                    float d = saturate((i.eyeDepth - _CS_Near) / max(_CS_Far - _CS_Near, 1e-4));
                    float g = 1.0 - sqrt(d);          // near = white, far = black
                    return float4(g, g, g, 1);
                }

                float3 N = normalize(i.worldN);
                float3 baseCol = _Color.rgb;
                if (facing < 0) { N = -N; baseCol = _BackColor.rgb; }

                float3 L = normalize(_CS_LightDir.xyz);
                float3 V = normalize(_WorldSpaceCameraPos.xyz - i.worldPos);
                float3 R = reflect(-L, N);
                float ndl = max(dot(N, L), 0.0);

                float3 ambient  = _Ka * _CS_Ambient.rgb * baseCol;
                float3 diffuse  = _Kd * ndl * _CS_LightColor.rgb * baseCol;
                float3 specular = (ndl > 0.0 ? 1.0 : 0.0) * _Ks * pow(max(dot(R, V), 0.0), _Shininess) * _CS_LightColor.rgb;
                return float4(ambient + diffuse + specular, 1);
            }
            ENDCG
        }
    }
    Fallback Off
}
