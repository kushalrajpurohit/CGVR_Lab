using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace CS4104
{
    /// <summary>
    /// Textbook 2-D clipping algorithms (Module 2) with step-by-step traces so the
    /// on-screen output can be compared with the hand calculations in the report.
    /// Region code bit order (TBRL): bit3 = Top(8), bit2 = Bottom(4), bit1 = Right(2), bit0 = Left(1).
    /// </summary>
    public static class Clipping
    {
        public const int LEFT = 1, RIGHT = 2, BOTTOM = 4, TOP = 8;

        public static int OutCode(Vector2 p, Rect w)
        {
            int c = 0;
            if (p.x < w.xMin) c |= LEFT; else if (p.x > w.xMax) c |= RIGHT;
            if (p.y < w.yMin) c |= BOTTOM; else if (p.y > w.yMax) c |= TOP;
            return c;
        }

        public static string Bits(int c)
        {
            return ((c >> 3) & 1).ToString() + ((c >> 2) & 1) + ((c >> 1) & 1) + (c & 1);
        }

        static string P(Vector2 p) { return "(" + p.x.ToString("0.##") + ", " + p.y.ToString("0.##") + ")"; }

        /// <summary>Cohen–Sutherland line clipping. Returns false if the line is rejected.</summary>
        public static bool CohenSutherland(Vector2 p0, Vector2 p1, Rect w, out Vector2 a, out Vector2 b, StringBuilder log)
        {
            int c0 = OutCode(p0, w), c1 = OutCode(p1, w);
            int iter = 0;
            while (true)
            {
                iter++;
                if (log != null) log.AppendLine("  It" + iter + ": P0" + P(p0) + "=" + Bits(c0) + "  P1" + P(p1) + "=" + Bits(c1));
                if ((c0 | c1) == 0)
                {
                    if (log != null) log.AppendLine("  OR = 0000 -> trivially ACCEPT");
                    a = p0; b = p1; return true;
                }
                if ((c0 & c1) != 0)
                {
                    if (log != null) log.AppendLine("  AND = " + Bits(c0 & c1) + " != 0000 -> trivially REJECT");
                    a = p0; b = p1; return false;
                }
                int co = c0 != 0 ? c0 : c1;
                float x, y; string edge;
                if ((co & TOP) != 0) { x = p0.x + (p1.x - p0.x) * (w.yMax - p0.y) / (p1.y - p0.y); y = w.yMax; edge = "top y=" + w.yMax; }
                else if ((co & BOTTOM) != 0) { x = p0.x + (p1.x - p0.x) * (w.yMin - p0.y) / (p1.y - p0.y); y = w.yMin; edge = "bottom y=" + w.yMin; }
                else if ((co & RIGHT) != 0) { y = p0.y + (p1.y - p0.y) * (w.xMax - p0.x) / (p1.x - p0.x); x = w.xMax; edge = "right x=" + w.xMax; }
                else { y = p0.y + (p1.y - p0.y) * (w.xMin - p0.x) / (p1.x - p0.x); x = w.xMin; edge = "left x=" + w.xMin; }
                Vector2 ip = new Vector2(x, y);
                if (log != null) log.AppendLine("  clip " + (co == c0 ? "P0" : "P1") + " against " + edge + " -> " + P(ip));
                if (co == c0) { p0 = ip; c0 = OutCode(p0, w); }
                else { p1 = ip; c1 = OutCode(p1, w); }
                if (iter > 8) { a = p0; b = p1; return false; }
            }
        }

        /// <summary>Liang–Barsky parametric line clipping, P(u) = P0 + u (P1 - P0), 0 &lt;= u &lt;= 1.</summary>
        public static bool LiangBarsky(Vector2 p0, Vector2 p1, Rect w, out Vector2 a, out Vector2 b, StringBuilder log)
        {
            float dx = p1.x - p0.x, dy = p1.y - p0.y;
            float[] p = { -dx, dx, -dy, dy };
            float[] q = { p0.x - w.xMin, w.xMax - p0.x, p0.y - w.yMin, w.yMax - p0.y };
            string[] names = { "left", "right", "bottom", "top" };
            float u1 = 0f, u2 = 1f;
            a = p0; b = p1;
            for (int k = 0; k < 4; k++)
            {
                if (Mathf.Approximately(p[k], 0f))
                {
                    if (log != null) log.AppendLine("  " + names[k] + ": p=0 (parallel), q=" + q[k]);
                    if (q[k] < 0) { if (log != null) log.AppendLine("  parallel and outside -> REJECT"); return false; }
                    continue;
                }
                float r = q[k] / p[k];
                if (log != null) log.AppendLine("  " + names[k] + ": p=" + p[k] + " q=" + q[k] + " r=" + r.ToString("0.####") + (p[k] < 0 ? " (entering)" : " (leaving)"));
                if (p[k] < 0) u1 = Mathf.Max(u1, r); else u2 = Mathf.Min(u2, r);
            }
            if (log != null) log.AppendLine("  u1 = " + u1.ToString("0.####") + ", u2 = " + u2.ToString("0.####"));
            if (u1 > u2) { if (log != null) log.AppendLine("  u1 > u2 -> REJECT"); return false; }
            a = new Vector2(p0.x + u1 * dx, p0.y + u1 * dy);
            b = new Vector2(p0.x + u2 * dx, p0.y + u2 * dy);
            if (log != null) log.AppendLine("  clipped: " + P(a) + " to " + P(b));
            return true;
        }

        /// <summary>Sutherland–Hodgman polygon clipping against the four window edges (left, right, bottom, top).</summary>
        public static List<Vector2> SutherlandHodgman(List<Vector2> poly, Rect w, StringBuilder log)
        {
            List<Vector2> output = new List<Vector2>(poly);
            for (int e = 0; e < 4 && output.Count > 0; e++)
            {
                List<Vector2> input = output;
                output = new List<Vector2>();
                for (int i = 0; i < input.Count; i++)
                {
                    Vector2 cur = input[i], prev = input[(i + input.Count - 1) % input.Count];
                    bool cin = Inside(cur, e, w), pin = Inside(prev, e, w);
                    if (cin)
                    {
                        if (!pin) output.Add(Intersect(prev, cur, e, w));
                        output.Add(cur);
                    }
                    else if (pin) output.Add(Intersect(prev, cur, e, w));
                }
                if (log != null)
                {
                    string[] names = { "left", "right", "bottom", "top" };
                    var sb = new StringBuilder();
                    foreach (var v in output) sb.Append(P(v)).Append(' ');
                    log.AppendLine("  after " + names[e] + ": " + sb);
                }
            }
            return output;
        }

        static bool Inside(Vector2 p, int e, Rect w)
        {
            switch (e)
            {
                case 0: return p.x >= w.xMin;
                case 1: return p.x <= w.xMax;
                case 2: return p.y >= w.yMin;
                default: return p.y <= w.yMax;
            }
        }

        static Vector2 Intersect(Vector2 a, Vector2 b, int e, Rect w)
        {
            if (e == 0 || e == 1)
            {
                float xc = e == 0 ? w.xMin : w.xMax;
                return new Vector2(xc, a.y + (b.y - a.y) * (xc - a.x) / (b.x - a.x));
            }
            float yc = e == 2 ? w.yMin : w.yMax;
            return new Vector2(a.x + (b.x - a.x) * (yc - a.y) / (b.y - a.y), yc);
        }
    }
}
