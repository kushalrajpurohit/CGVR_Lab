using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.Rendering;

namespace CS4104
{
    /// <summary>
    /// CS4104 Case Study 2 – Industrial Design and Architecture.
    /// A single component that builds a complete, self-contained VR design-review
    /// demo at runtime (no imported assets, no input packages, no UI packages):
    ///   1  CAD profile -> 3D mesh (extrusion + lathe B-rep, tessellation, Euler check)
    ///   2  Composite transformation M = T * R * S of a wheel rim (hand matrix vs Unity TRS)
    ///   3  2-D clipping: Cohen–Sutherland, Liang–Barsky, Sutherland–Hodgman
    ///   4  Hidden-surface removal: back-face culling, Z-buffer view, section plane, frustum culling
    ///   5  Stereo (dual-display) rendering, frame budget and Bengaluru–Detroit collaboration latency
    /// Controls: left/right mouse drag = orbit, wheel = zoom, keys 1-5 = modes, H = hide panel.
    /// </summary>
    public class CarDesignDemo : MonoBehaviour
    {
        enum Mode { CadMesh = 0, Transformations = 1, Clip2D = 2, HiddenSurface = 3, StereoVR = 4 }

        static readonly string[] ModeNames =
        {
            "1  CAD → Mesh", "2  Transform T·R·S", "3  Clipping 2D", "4  Hidden Surfaces", "5  Stereo VR / Collab"
        };

        const int HelperLayer = 31;                 // frustum gizmo – seen only by the observer camera

        Mode mode = Mode.CadMesh;
        Shader phongShader, lineShader;
        Material matPaint, matTire, matRim, matFloor, matPart, matTurntable, matChrome, matLines, matAvatarA, matAvatarB;
        readonly List<Material> solidMats = new List<Material>();

        Camera cam, eye2, observer;
        float yaw = 35f, pitch = 18f, dist = 7f;
        Vector3 target = new Vector3(0, 0.7f, 0);

        // ---------------------------------------------------------------- car
        Transform turntable, carRoot;
        MeshFilter bodyMF;
        readonly List<MeshFilter> rimMFs = new List<MeshFilter>();
        readonly List<MeshFilter> tireMFs = new List<MeshFilter>();
        readonly List<Transform> wheels = new List<Transform>();
        readonly List<Vector3> wheelBasePos = new List<Vector3>();
        readonly Dictionary<MeshFilter, MeshFilter> wireOf = new Dictionary<MeshFilter, MeshFilter>();
        MeshFilter profileLineMF;
        int latheSegments = 32, builtSegments = -1;
        float extrude = 1f, builtExtrude = -1f;
        bool wireframe, showProfile = true, explode;
        float explodeT;
        const float CarWidth = 1.8f;
        MeshKit.BRepStats bodyStats, rimStats, tireStats;
        int carTriangles;

        // ---------------------------------------------------------------- studio parts (frustum culling)
        readonly List<Renderer> parts = new List<Renderer>();
        readonly List<int> partTris = new List<int>();
        MaterialPropertyBlock mpb;
        GameObject frustumGizmo; Mesh frustumMesh;
        int visibleParts, visiblePartTris, totalPartTris;

        // ---------------------------------------------------------------- hidden surfaces
        int cullMode = 2;                                       // 0 Off, 1 Front, 2 Back (UnityEngine.Rendering.CullMode)
        bool depthView, sectionOn;
        float sectionD = 0.3f, nearPlane = 0.1f, farPlane = 60f;
        int frontTris, backTris, bfFrame;
        struct MeshCache { public Transform t; public Vector3[] v; public int[] i; }
        readonly List<MeshCache> carCache = new List<MeshCache>();

        // ---------------------------------------------------------------- transformation demo (millimetres)
        Transform mmSpace, rimT, markerT, ghostMarkerT;
        bool correctOrder = true;
        float stageT, stageTarget;
        static readonly Vector3 TestPointMM = new Vector3(0f, 0f, 216f);

        // ---------------------------------------------------------------- clipping demo
        Transform clipRoot; Mesh clipMesh;
        static readonly Rect ClipWin = new Rect(100, 100, 300, 200);   // xmin=100, ymin=100, xmax=400, ymax=300
        readonly List<Vector2[]> clipLines = new List<Vector2[]>();
        int selectedLine;
        bool useLiangBarsky, showPolygon = true;
        readonly List<Vector2> clipPolygon = new List<Vector2> { new Vector2(250, 50), new Vector2(450, 200), new Vector2(150, 350) };
        string clipTrace = "", polyTrace = "";
        bool clipDirty = true;

        // ---------------------------------------------------------------- stereo / collaboration
        float ipdMM = 64f, rttMS = 136f, avgDt = 1f / 60f;
        bool stress; GameObject stressRoot;
        float turntableAngle, turntableTarget;
        struct NetCmd { public float arrive; public float delta; }
        readonly List<NetCmd> inFlight = new List<NetCmd>();
        Transform avatarA, avatarB;
        string netLog = "";

        // ---------------------------------------------------------------- GUI
        bool panelVisible = true;
        Vector2 scroll;
        float guiScale = 1f;
        bool draggingCamera;
        GUIStyle hStyle, txtStyle, monoStyle, boxStyle, smallStyle;
        Rect panelRectPx;

        // =================================================================== setup
        void Start()
        {
            phongShader = Shader.Find("CS4104/Phong");
            lineShader = Shader.Find("CS4104/Lines");
            if (phongShader == null || lineShader == null)
            {
                Debug.LogError("[CS4104] Shaders not found. Make sure the package Runtime/Resources folder was imported.");
                enabled = false; return;
            }
            mpb = new MaterialPropertyBlock();

            matPaint = Solid(new Color(0.75f, 0.06f, 0.08f), 0.7f, 64f);
            matTire = Solid(new Color(0.08f, 0.08f, 0.09f), 0.15f, 8f);
            matRim = Solid(new Color(0.72f, 0.74f, 0.78f), 0.9f, 96f);
            matChrome = Solid(new Color(0.80f, 0.82f, 0.86f), 0.9f, 96f);
            matFloor = Solid(new Color(0.32f, 0.34f, 0.37f), 0.05f, 4f);
            matPart = Solid(new Color(0.55f, 0.57f, 0.60f), 0.3f, 16f);
            matTurntable = Solid(new Color(0.20f, 0.22f, 0.26f), 0.4f, 32f);
            matAvatarA = Solid(new Color(0.15f, 0.45f, 0.95f), 0.3f, 16f);
            matAvatarB = Solid(new Color(1.0f, 0.55f, 0.10f), 0.3f, 16f);
            matLines = new Material(lineShader);

            Shader.SetGlobalVector("_CS_LightDir", new Vector4(0.45f, 0.80f, -0.40f, 0f).normalized);
            Shader.SetGlobalColor("_CS_LightColor", new Color(1f, 0.97f, 0.92f));
            Shader.SetGlobalColor("_CS_Ambient", new Color(0.55f, 0.60f, 0.70f));
            Shader.SetGlobalVector("_CS_ClipPlane", new Vector4(1, 0, 0, sectionD));
            Shader.SetGlobalFloat("_CS_ClipOn", 0f);
            Shader.SetGlobalFloat("_CS_DepthView", 0f);

            BuildCameras();
            BuildStudio();
            BuildCar();
            BuildTransformDemo();
            BuildClipDemo();
            BuildAvatars();
            SetMode(Mode.CadMesh);
        }

        Material Solid(Color c, float ks, float shininess)
        {
            var m = new Material(phongShader);
            m.SetColor("_Color", c);
            m.SetFloat("_Ks", ks);
            m.SetFloat("_Shininess", shininess);
            m.SetFloat("_Cull", 2f);
            solidMats.Add(m);
            return m;
        }

        GameObject MakeObj(string name, Mesh mesh, Material mat, Transform parent)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.AddComponent<MeshFilter>().sharedMesh = mesh;
            var mr = go.AddComponent<MeshRenderer>();
            mr.sharedMaterial = mat;
            mr.shadowCastingMode = ShadowCastingMode.Off;
            mr.receiveShadows = false;
            return go;
        }

        Camera NewCamera(string name)
        {
            var go = new GameObject(name);
            go.transform.SetParent(transform, false);
            var c = go.AddComponent<Camera>();
            c.clearFlags = CameraClearFlags.SolidColor;
            c.backgroundColor = new Color(0.10f, 0.11f, 0.13f);
            c.nearClipPlane = 0.1f;
            c.farClipPlane = 300f;
            c.fieldOfView = 60f;
            return c;
        }

        void BuildCameras()
        {
            cam = NewCamera("Main Camera (Left Eye)");
            cam.gameObject.tag = "MainCamera";
            cam.cullingMask = ~(1 << HelperLayer);
            cam.depth = 0;

            eye2 = NewCamera("Right Eye Camera");
            eye2.cullingMask = ~(1 << HelperLayer);
            eye2.depth = 1;

            observer = NewCamera("Observer Camera (top view)");
            observer.orthographic = true;
            observer.orthographicSize = 34f;
            observer.depth = 2;
            observer.backgroundColor = new Color(0.05f, 0.06f, 0.08f);
            observer.transform.position = new Vector3(0, 120f, 0);
            observer.transform.rotation = Quaternion.Euler(90f, 0f, 0f);
            observer.farClipPlane = 400f;
        }

        void BuildStudio()
        {
            var studio = new GameObject("Design Studio").transform;
            studio.SetParent(transform, false);

            var fb = new FlatMeshBuilder();
            float s = 45f;
            fb.AddQuad(new Vector3(-s, 0, -s), new Vector3(s, 0, -s), new Vector3(s, 0, s), new Vector3(-s, 0, s), Vector3.up);
            MakeObj("Floor", fb.ToMesh("Floor"), matFloor, studio);

            var grid = new LineBuilder();
            for (int i = -40; i <= 40; i++)
            {
                Color c = i % 5 == 0 ? new Color(0.45f, 0.48f, 0.52f) : new Color(0.27f, 0.29f, 0.32f);
                grid.Add(new Vector3(i, 0.003f, -40), new Vector3(i, 0.003f, 40), c);
                grid.Add(new Vector3(-40, 0.003f, i), new Vector3(40, 0.003f, i), c);
            }
            MakeObj("Floor Grid (1 m)", grid.ToMesh("Grid"), matLines, studio);

            // turntable: lathe around X, rotated so its axis is world Y
            var tb = new FlatMeshBuilder();
            MeshKit.Lathe(tb, new List<Vector2> { new Vector2(0f, 0f), new Vector2(0.05f, 0f), new Vector2(0.05f, 3.2f), new Vector2(0f, 3.2f) }, 64, 1f);
            var tt = MakeObj("Turntable", tb.ToMesh("Turntable"), matTurntable, studio);
            tt.transform.localRotation = Quaternion.Euler(0, 0, 90f);
            turntable = new GameObject("Turntable Pivot").transform;
            turntable.SetParent(studio, false);

            // scattered design-studio objects (pillars, crates, clay bucks) for frustum-culling statistics
            var box = new FlatMeshBuilder(); box.AddBox(Vector3.zero, Vector3.one, Quaternion.identity);
            Mesh boxMesh = box.ToMesh("Box");
            var cyl = new FlatMeshBuilder();
            MeshKit.Lathe(cyl, new List<Vector2> { new Vector2(-0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(0.5f, 0.5f), new Vector2(-0.5f, 0.5f) }, 24, 1f);
            Mesh cylMesh = cyl.ToMesh("Cylinder");
            var partsRoot = new GameObject("Studio Parts (frustum culling test)").transform;
            partsRoot.SetParent(studio, false);
            Random.State old = Random.state;
            Random.InitState(4104);
            for (int k = 0; k < 160; k++)
            {
                float ang = Random.value * Mathf.PI * 2f, rad = Random.Range(6.5f, 30f);
                bool isCyl = Random.value < 0.4f;
                float h = Random.Range(0.4f, 3.2f), w = Random.Range(0.4f, 1.6f);
                var go = MakeObj(isCyl ? "Pillar " + k : "Crate " + k, isCyl ? cylMesh : boxMesh, matPart, partsRoot);
                go.transform.localPosition = new Vector3(Mathf.Cos(ang) * rad, h * 0.5f, Mathf.Sin(ang) * rad);
                if (isCyl) { go.transform.localRotation = Quaternion.Euler(0, 0, 90f); go.transform.localScale = new Vector3(h, w, w); }
                else { go.transform.localRotation = Quaternion.Euler(0, Random.Range(0f, 90f), 0); go.transform.localScale = new Vector3(w, h, w); }
                var r = go.GetComponent<Renderer>();
                parts.Add(r);
                int tris = (isCyl ? cylMesh.triangles.Length : boxMesh.triangles.Length) / 3;
                partTris.Add(tris);
                totalPartTris += tris;
            }
            Random.state = old;

            frustumMesh = new Mesh { name = "Frustum Gizmo" };
            frustumGizmo = MakeObj("View Frustum Gizmo", frustumMesh, matLines, transform);
            frustumGizmo.layer = HelperLayer;
        }

        // =================================================================== car (Module 1 of the demo)
        void BuildCar()
        {
            carRoot = new GameObject("Car Prototype (1:1)").transform;
            carRoot.SetParent(turntable, false);
            carRoot.localPosition = new Vector3(0, 0.05f, 0);

            bodyMF = MakeObj("Body (extruded B-rep)", new Mesh(), matPaint, carRoot).GetComponent<MeshFilter>();
            AddWire(bodyMF);

            var pl = MakeObj("2D CAD Profile", new Mesh(), matLines, carRoot);
            profileLineMF = pl.GetComponent<MeshFilter>();

            float wx = CarWidth * 0.5f - 0.14f;
            Vector3[] pos = { new Vector3(wx, 0.33f, 1.4f), new Vector3(-wx, 0.33f, 1.4f), new Vector3(wx, 0.33f, -1.4f), new Vector3(-wx, 0.33f, -1.4f) };
            string[] names = { "Wheel FR", "Wheel FL", "Wheel RR", "Wheel RL" };
            for (int i = 0; i < 4; i++)
            {
                var w = new GameObject(names[i]).transform;
                w.SetParent(carRoot, false);
                w.localPosition = pos[i];
                if (pos[i].x < 0) w.localRotation = Quaternion.Euler(0, 180f, 0);   // outer face (+X local) points outwards
                wheels.Add(w); wheelBasePos.Add(pos[i]);
                var rim = MakeObj("Rim (lathe + spokes)", new Mesh(), matRim, w).GetComponent<MeshFilter>();
                var tire = MakeObj("Tyre (lathe)", new Mesh(), matTire, w).GetComponent<MeshFilter>();
                rimMFs.Add(rim); tireMFs.Add(tire);
                AddWire(rim); AddWire(tire);
            }
            RebuildCar(true);
        }

        void AddWire(MeshFilter mf)
        {
            var go = MakeObj("Wireframe", new Mesh(), matLines, mf.transform);
            wireOf[mf] = go.GetComponent<MeshFilter>();
            go.SetActive(false);
        }

        void SetMesh(MeshFilter mf, Mesh m, Color wireCol)
        {
            if (mf.sharedMesh != null) Destroy(mf.sharedMesh);
            mf.sharedMesh = m;
            MeshFilter w;
            if (wireOf.TryGetValue(mf, out w))
            {
                if (w.sharedMesh != null) Destroy(w.sharedMesh);
                w.sharedMesh = MeshKit.Wireframe(m, wireCol);
            }
        }

        void RebuildCar(bool force)
        {
            bool bodyChanged = force || !Mathf.Approximately(extrude, builtExtrude);
            bool wheelsChanged = force || latheSegments != builtSegments;
            if (bodyChanged)
            {
                builtExtrude = extrude;
                float width = CarWidth * Mathf.Max(extrude, 0.01f);
                SetMesh(bodyMF, MeshKit.Extrude(MeshKit.CarProfile(), width, "CarBody"), new Color(1f, 0.85f, 0.2f));
                bodyStats = MeshKit.Stats(bodyMF.sharedMesh);

                var lb = new LineBuilder();
                List<Vector2> p = MeshKit.CarProfile();
                float x = width * 0.5f + 0.004f;
                for (int i = 0; i < p.Count; i++)
                {
                    Vector2 a = p[i], b = p[(i + 1) % p.Count];
                    lb.Add(new Vector3(x, a.y, a.x), new Vector3(x, b.y, b.x), new Color(1f, 0.9f, 0.1f));
                }
                if (profileLineMF.sharedMesh != null) Destroy(profileLineMF.sharedMesh);
                profileLineMF.sharedMesh = lb.ToMesh("Profile");
            }
            if (wheelsChanged)
            {
                builtSegments = latheSegments;
                for (int i = 0; i < 4; i++)
                {
                    SetMesh(rimMFs[i], MeshKit.Rim(latheSegments, 1f, "Rim"), new Color(0.2f, 1f, 1f));
                    SetMesh(tireMFs[i], MeshKit.Tire(latheSegments, "Tyre"), new Color(0.6f, 0.6f, 0.6f));
                }
                rimStats = MeshKit.Stats(rimMFs[0].sharedMesh);
                tireStats = MeshKit.Stats(tireMFs[0].sharedMesh);
            }
            if (bodyChanged || wheelsChanged)
            {
                carTriangles = bodyMF.sharedMesh.triangles.Length / 3 + 4 * (rimMFs[0].sharedMesh.triangles.Length + tireMFs[0].sharedMesh.triangles.Length) / 3;
                carCache.Clear();
                AddCache(bodyMF);
                for (int i = 0; i < 4; i++) { AddCache(rimMFs[i]); AddCache(tireMFs[i]); }
            }
        }

        void AddCache(MeshFilter mf)
        {
            MeshCache c; c.t = mf.transform; c.v = mf.sharedMesh.vertices; c.i = mf.sharedMesh.triangles;
            carCache.Add(c);
        }

        // =================================================================== transformation demo (millimetre space)
        void BuildTransformDemo()
        {
            mmSpace = new GameObject("Transform Demo Space (units = mm)").transform;
            mmSpace.SetParent(transform, false);
            mmSpace.position = new Vector3(-1000f, 0f, 0f);
            mmSpace.localScale = Vector3.one * 0.001f;                 // 1 local unit = 1 mm

            var g = new LineBuilder();
            for (int i = -500; i <= 500; i += 50)
            {
                Color c = i == 0 ? new Color(0.6f, 0.6f, 0.6f) : (i % 100 == 0 ? new Color(0.36f, 0.38f, 0.42f) : new Color(0.22f, 0.23f, 0.26f));
                g.Add(new Vector3(i, -1, -500), new Vector3(i, -1, 500), c);
                g.Add(new Vector3(-500, -1, i), new Vector3(500, -1, i), c);
            }
            g.Add(Vector3.zero, new Vector3(320, 0, 0), Color.red);       // X axis (axle)
            g.Add(Vector3.zero, new Vector3(0, 320, 0), Color.green);     // Y axis (up)
            g.Add(Vector3.zero, new Vector3(0, 0, 320), new Color(0.2f, 0.5f, 1f)); // Z axis (forward)
            g.Add(new Vector3(-30, 0, 50), new Vector3(30, 0, 50), new Color(0.2f, 0.5f, 1f));   // tick at z = 50 mm
            MakeObj("Grid 50 mm + axes", g.ToMesh("mmGrid"), matLines, mmSpace);

            Mesh rimMesh = MeshKit.Rim(48, 1000f, "Rim_mm");
            var ghost = MakeObj("Original rim (ghost, identity)", MeshKit.Wireframe(rimMesh, new Color(0.45f, 0.45f, 0.5f)), matLines, mmSpace);
            ghost.transform.localPosition = Vector3.zero;

            rimT = MakeObj("Rim (transformed by M)", rimMesh, matChrome, mmSpace).transform;

            var mb = new FlatMeshBuilder(); mb.AddBox(Vector3.zero, Vector3.one * 14f, Quaternion.identity);
            Mesh markerMesh = mb.ToMesh("Marker");
            var red = Solid(new Color(1f, 0.15f, 0.15f), 0.2f, 8f);
            var yel = Solid(new Color(1f, 0.85f, 0.1f), 0.2f, 8f);
            markerT = MakeObj("Test point P' (moves with rim)", markerMesh, red, rimT).transform;
            markerT.localPosition = TestPointMM;
            ghostMarkerT = MakeObj("Test point P (original)", markerMesh, yel, mmSpace).transform;
            ghostMarkerT.localPosition = TestPointMM;
        }

        static Matrix4x4 MScale(float s) { var m = Matrix4x4.identity; m.m00 = s; m.m11 = s; m.m22 = s; return m; }
        static Matrix4x4 MRotY(float deg)
        {
            float r = deg * Mathf.Deg2Rad, c = Mathf.Cos(r), s = Mathf.Sin(r);
            var m = Matrix4x4.identity; m.m00 = c; m.m02 = s; m.m20 = -s; m.m22 = c; return m;
        }
        static Matrix4x4 MTrans(float x, float y, float z) { var m = Matrix4x4.identity; m.m03 = x; m.m13 = y; m.m23 = z; return m; }

        /// <summary>Explicit row-by-column product, written out to mirror the hand calculation.</summary>
        static Matrix4x4 Mul(Matrix4x4 a, Matrix4x4 b)
        {
            var r = new Matrix4x4();
            for (int i = 0; i < 4; i++)
                for (int j = 0; j < 4; j++)
                {
                    float sum = 0f;
                    for (int k = 0; k < 4; k++) sum += a[i, k] * b[k, j];
                    r[i, j] = sum;
                }
            return r;
        }

        void StageValues(out float s, out float ang, out float tz)
        {
            if (correctOrder)
            {
                s = Mathf.Lerp(1f, 1.5f, Mathf.Clamp01(stageT));
                ang = 45f * Mathf.Clamp01(stageT - 1f);
                tz = 50f * Mathf.Clamp01(stageT - 2f);
            }
            else
            {
                tz = 50f * Mathf.Clamp01(stageT);
                ang = 45f * Mathf.Clamp01(stageT - 1f);
                s = Mathf.Lerp(1f, 1.5f, Mathf.Clamp01(stageT - 2f));
            }
        }

        Matrix4x4 CurrentM()
        {
            float s, ang, tz; StageValues(out s, out ang, out tz);
            return correctOrder ? Mul(MTrans(0, 0, tz), Mul(MRotY(ang), MScale(s)))
                                : Mul(MScale(s), Mul(MRotY(ang), MTrans(0, 0, tz)));
        }

        void UpdateTransformDemo()
        {
            stageT = Mathf.MoveTowards(stageT, stageTarget, Time.deltaTime * 0.8f);
            float s, ang, tz; StageValues(out s, out ang, out tz);
            Matrix4x4 M = CurrentM();
            rimT.localPosition = M.GetColumn(3);
            rimT.localRotation = Quaternion.Euler(0f, ang, 0f);
            rimT.localScale = Vector3.one * s;
        }

        // =================================================================== clipping demo
        void BuildClipDemo()
        {
            clipRoot = new GameObject("Clipping Demo Space (units = pixels)").transform;
            clipRoot.SetParent(transform, false);
            clipRoot.position = new Vector3(1000f, 0f, 0f);
            clipRoot.localScale = Vector3.one * 0.01f;
            clipMesh = new Mesh { name = "Clip2D" };
            MakeObj("Clipping Figure", clipMesh, matLines, clipRoot);
            ReportLines();
        }

        void ReportLines()
        {
            clipLines.Clear();
            clipLines.Add(new[] { new Vector2(50, 150), new Vector2(450, 250) });    // L1 worked example
            clipLines.Add(new[] { new Vector2(150, 50), new Vector2(350, 350) });    // L2 crosses bottom and top
            clipLines.Add(new[] { new Vector2(20, 320), new Vector2(80, 380) });     // L3 trivially rejected
            clipLines.Add(new[] { new Vector2(150, 150), new Vector2(350, 250) });   // L4 trivially accepted
            clipLines.Add(new[] { new Vector2(50, 250), new Vector2(250, 350) });    // L5 crosses left and top
            selectedLine = 0; clipDirty = true;
        }

        void RandomLines()
        {
            clipLines.Clear();
            for (int i = 0; i < 6; i++)
                clipLines.Add(new[] { new Vector2(Random.Range(10, 490), Random.Range(10, 390)), new Vector2(Random.Range(10, 490), Random.Range(10, 390)) });
            selectedLine = 0; clipDirty = true;
        }

        void RebuildClipFigure()
        {
            clipDirty = false;
            var q = new QuadLineBuilder();
            for (int x = 0; x <= 500; x += 50) q.Line(new Vector2(x, 0), new Vector2(x, 400), 0.8f, new Color(0.2f, 0.21f, 0.24f), 0f);
            for (int y = 0; y <= 400; y += 50) q.Line(new Vector2(0, y), new Vector2(500, y), 0.8f, new Color(0.2f, 0.21f, 0.24f), 0f);
            Color ext = new Color(0.35f, 0.36f, 0.42f);
            q.Line(new Vector2(ClipWin.xMin, 0), new Vector2(ClipWin.xMin, 400), 1.2f, ext, -0.5f);
            q.Line(new Vector2(ClipWin.xMax, 0), new Vector2(ClipWin.xMax, 400), 1.2f, ext, -0.5f);
            q.Line(new Vector2(0, ClipWin.yMin), new Vector2(500, ClipWin.yMin), 1.2f, ext, -0.5f);
            q.Line(new Vector2(0, ClipWin.yMax), new Vector2(500, ClipWin.yMax), 1.2f, ext, -0.5f);

            var log = new StringBuilder();
            if (showPolygon)
            {
                var plog = new StringBuilder();
                List<Vector2> clipped = Clipping.SutherlandHodgman(clipPolygon, ClipWin, plog);
                q.FillPolygon(clipped, new Color(0.10f, 0.32f, 0.22f), -0.8f);
                for (int i = 0; i < clipPolygon.Count; i++)
                    q.Line(clipPolygon[i], clipPolygon[(i + 1) % clipPolygon.Count], 1.6f, new Color(1f, 0.6f, 0.1f), -1.5f);
                for (int i = 0; i < clipped.Count; i++)
                {
                    q.Line(clipped[i], clipped[(i + 1) % clipped.Count], 3f, new Color(1f, 0.92f, 0.2f), -1.8f);
                    q.Dot(clipped[i], 7f, new Color(1f, 0.92f, 0.2f), -2.5f);
                }
                polyTrace = "Input triangle (250,50) (450,200) (150,350)\n" + plog;
            }
            q.Rect(new Vector2(ClipWin.xMin, ClipWin.yMin), new Vector2(ClipWin.xMax, ClipWin.yMax), 3f, Color.white, -1f);

            for (int i = 0; i < clipLines.Count; i++)
            {
                Vector2 p0 = clipLines[i][0], p1 = clipLines[i][1], a, b;
                StringBuilder sb = i == selectedLine ? log : null;
                bool ok = useLiangBarsky ? Clipping.LiangBarsky(p0, p1, ClipWin, out a, out b, sb)
                                         : Clipping.CohenSutherland(p0, p1, ClipWin, out a, out b, sb);
                bool sel = i == selectedLine;
                q.Line(p0, p1, sel ? 2.6f : 1.8f, new Color(0.85f, 0.2f, 0.2f), -2f);
                q.Dot(p0, 6f, new Color(0.85f, 0.2f, 0.2f), -2.2f);
                q.Dot(p1, 6f, new Color(0.85f, 0.2f, 0.2f), -2.2f);
                if (ok)
                {
                    q.Line(a, b, sel ? 6f : 4.5f, new Color(0.2f, 1f, 0.35f), -3f);
                    q.Dot(a, 9f, new Color(0.2f, 1f, 0.35f), -3.5f);
                    q.Dot(b, 9f, new Color(0.2f, 1f, 0.35f), -3.5f);
                }
            }
            q.Fill(clipMesh);
            clipTrace = log.ToString();
        }

        Vector2 ClipToGui(Vector2 p)
        {
            Vector3 w = clipRoot.TransformPoint(new Vector3(p.x, p.y, -5f));
            Vector3 sp = cam.WorldToScreenPoint(w);
            return new Vector2(sp.x / guiScale, (Screen.height - sp.y) / guiScale);
        }

        // =================================================================== avatars
        void BuildAvatars()
        {
            avatarA = MakeAvatar("Designer – Bengaluru (local)", matAvatarA);
            avatarB = MakeAvatar("Designer – Detroit (remote)", matAvatarB);
            avatarA.position = new Vector3(0f, 0f, -4.6f);
            avatarA.rotation = Quaternion.LookRotation(Vector3.forward);
        }

        Transform MakeAvatar(string name, Material m)
        {
            var root = new GameObject(name).transform;
            root.SetParent(transform, false);
            var b = new FlatMeshBuilder();
            b.AddBox(new Vector3(0, 0.75f, 0), new Vector3(0.45f, 1.5f, 0.28f), Quaternion.identity);
            b.AddBox(new Vector3(0, 1.68f, 0), new Vector3(0.26f, 0.28f, 0.26f), Quaternion.identity);
            b.AddBox(new Vector3(0, 1.70f, 0.16f), new Vector3(0.22f, 0.10f, 0.08f), Quaternion.identity); // headset
            MakeObj("Body", b.ToMesh("Avatar"), m, root);
            return root;
        }

        // =================================================================== mode handling
        void SetMode(Mode m)
        {
            mode = m;
            cam.orthographic = false;
            cam.rect = new Rect(0, 0, 1, 1);
            cam.fieldOfView = 60f;
            cam.nearClipPlane = 0.05f; cam.farClipPlane = 300f;
            eye2.enabled = false;
            observer.enabled = false;
            frustumGizmo.SetActive(false);
            Shader.SetGlobalFloat("_CS_ClipOn", 0f);
            Shader.SetGlobalFloat("_CS_DepthView", 0f);
            ApplyCull(2);
            ResetPartColours();
            switch (m)
            {
                case Mode.CadMesh: target = new Vector3(0, 0.7f, 0); yaw = 35f; pitch = 16f; dist = 7.2f; break;
                case Mode.Transformations: target = new Vector3(-1000f, 0f, 0.03f); yaw = -135f; pitch = 50f; dist = 1.3f; cam.nearClipPlane = 0.01f; break;
                case Mode.Clip2D: cam.orthographic = true; clipDirty = true; break;
                case Mode.HiddenSurface:
                    target = new Vector3(0, 0.7f, 0); yaw = -35f; pitch = 18f; dist = 8.5f;
                    observer.enabled = true; frustumGizmo.SetActive(true);
                    cam.nearClipPlane = nearPlane; cam.farClipPlane = farPlane;
                    ApplyCull(cullMode);
                    break;
                case Mode.StereoVR: target = new Vector3(0, 0.8f, 0); yaw = 20f; pitch = 12f; dist = 6.5f; eye2.enabled = true; cam.fieldOfView = 80f; eye2.fieldOfView = 80f; break;
            }
        }

        void ApplyCull(int c)
        {
            foreach (var m in solidMats) m.SetFloat("_Cull", c);
        }

        void ResetPartColours()
        {
            foreach (var r in parts) r.SetPropertyBlock(null);
        }

        // =================================================================== per-frame
        void Update()
        {
            if (phongShader == null) return;
            avgDt = Mathf.Lerp(avgDt, Time.unscaledDeltaTime, 0.05f);

            // turntable (local edits immediate, remote edits arrive after one-way latency)
            for (int i = inFlight.Count - 1; i >= 0; i--)
                if (Time.time >= inFlight[i].arrive)
                {
                    turntableTarget += inFlight[i].delta;
                    netLog = "Remote command applied at t = " + Time.time.ToString("0.00") + " s";
                    inFlight.RemoveAt(i);
                }
            turntableAngle = Mathf.MoveTowardsAngle(turntableAngle, turntableTarget, 90f * Time.deltaTime);
            turntable.localRotation = Quaternion.Euler(0, turntableAngle, 0);

            // Detroit avatar walks round the car; we render the pose that is one-way-latency old
            float delayed = Time.time - rttMS * 0.0005f;
            float a = delayed * 0.25f;
            avatarB.position = new Vector3(Mathf.Sin(a) * 4.8f, 0f, Mathf.Cos(a) * 4.8f);
            avatarB.rotation = Quaternion.LookRotation(-avatarB.position.normalized);

            RebuildCar(false);
            explodeT = Mathf.MoveTowards(explodeT, explode ? 1f : 0f, Time.deltaTime * 1.5f);
            for (int i = 0; i < 4; i++)
                wheels[i].localPosition = wheelBasePos[i] + new Vector3(Mathf.Sign(wheelBasePos[i].x) * 0.9f * explodeT, 0, 0);
            bool wireOn = wireframe && (mode == Mode.CadMesh || mode == Mode.HiddenSurface);
            foreach (var kv in wireOf) kv.Value.gameObject.SetActive(wireOn);
            profileLineMF.gameObject.SetActive(showProfile && mode == Mode.CadMesh);

            UpdateTransformDemo();
            if (mode == Mode.Clip2D && clipDirty) RebuildClipFigure();
        }

        void LateUpdate()
        {
            if (phongShader == null) return;
            pitch = Mathf.Clamp(pitch, -10f, 89f);
            dist = Mathf.Clamp(dist, mode == Mode.Transformations ? 0.3f : 1.5f, mode == Mode.Transformations ? 4f : 60f);
            Quaternion rot = Quaternion.Euler(pitch, yaw, 0f);
            Vector3 pos = target - rot * Vector3.forward * dist;

            if (mode == Mode.Clip2D)
            {
                float aspect = (float)Screen.width / Mathf.Max(1, Screen.height);
                float size = Mathf.Max(2.35f, 4.3f / aspect);
                cam.orthographicSize = size;
                float halfW = size * aspect;
                float shift = panelVisible ? 0.30f * halfW : 0f;
                Vector3 c = clipRoot.position + new Vector3(2.5f - shift, 2.0f, -10f);
                cam.transform.SetPositionAndRotation(c, Quaternion.identity);
            }
            else if (mode == Mode.StereoVR)
            {
                Vector3 right = rot * Vector3.right;
                float half = ipdMM * 0.0005f;
                cam.rect = new Rect(0, 0, 0.5f, 1f);
                eye2.rect = new Rect(0.5f, 0, 0.5f, 1f);
                cam.transform.SetPositionAndRotation(pos - right * half, rot);
                eye2.transform.SetPositionAndRotation(pos + right * half, rot);
            }
            else
            {
                cam.transform.SetPositionAndRotation(pos, rot);
            }

            if (mode == Mode.HiddenSurface)
            {
                cam.nearClipPlane = nearPlane;
                cam.farClipPlane = Mathf.Max(farPlane, nearPlane + 0.5f);
                observer.rect = new Rect(0.70f, 0.02f, 0.29f, 0.40f);
                Shader.SetGlobalFloat("_CS_DepthView", depthView ? 1f : 0f);
                Shader.SetGlobalFloat("_CS_Near", cam.nearClipPlane);
                Shader.SetGlobalFloat("_CS_Far", Mathf.Min(cam.farClipPlane, 40f));
                Shader.SetGlobalFloat("_CS_ClipOn", sectionOn ? 1f : 0f);
                Shader.SetGlobalVector("_CS_ClipPlane", new Vector4(1f, 0f, 0f, sectionD));
                UpdateFrustumCulling();
                if (++bfFrame % 5 == 0) CountBackFaces();
            }
        }

        void UpdateFrustumCulling()
        {
            Plane[] planes = GeometryUtility.CalculateFrustumPlanes(cam);
            visibleParts = 0; visiblePartTris = 0;
            Color vis = new Color(0.2f, 0.85f, 0.3f), cul = new Color(0.9f, 0.18f, 0.15f);
            for (int i = 0; i < parts.Count; i++)
            {
                bool v = GeometryUtility.TestPlanesAABB(planes, parts[i].bounds);
                if (v) { visibleParts++; visiblePartTris += partTris[i]; }
                mpb.SetColor("_Color", v ? vis : cul);
                parts[i].SetPropertyBlock(mpb);
            }

            // frustum gizmo (drawn only for the observer camera)
            var corners = new Vector3[4];
            var lb = new LineBuilder();
            Color fc = new Color(1f, 0.9f, 0.2f);
            Vector3[] nearC = new Vector3[4], farC = new Vector3[4];
            cam.CalculateFrustumCorners(new Rect(0, 0, 1, 1), cam.nearClipPlane, Camera.MonoOrStereoscopicEye.Mono, corners);
            for (int i = 0; i < 4; i++) nearC[i] = cam.transform.TransformPoint(corners[i]);
            cam.CalculateFrustumCorners(new Rect(0, 0, 1, 1), Mathf.Min(cam.farClipPlane, 60f), Camera.MonoOrStereoscopicEye.Mono, corners);
            for (int i = 0; i < 4; i++) farC[i] = cam.transform.TransformPoint(corners[i]);
            for (int i = 0; i < 4; i++)
            {
                lb.Add(nearC[i], nearC[(i + 1) % 4], fc);
                lb.Add(farC[i], farC[(i + 1) % 4], fc);
                lb.Add(nearC[i], farC[i], fc);
            }
            lb.Fill(frustumMesh);
        }

        void CountBackFaces()
        {
            Vector3 eye = cam.transform.position;
            int f = 0, b = 0;
            foreach (var c in carCache)
            {
                Matrix4x4 l2w = c.t.localToWorldMatrix;
                for (int i = 0; i < c.i.Length; i += 3)
                {
                    Vector3 p0 = l2w.MultiplyPoint3x4(c.v[c.i[i]]);
                    Vector3 p1 = l2w.MultiplyPoint3x4(c.v[c.i[i + 1]]);
                    Vector3 p2 = l2w.MultiplyPoint3x4(c.v[c.i[i + 2]]);
                    Vector3 n = Vector3.Cross(p1 - p0, p2 - p0);       // geometric normal from the winding
                    if (Vector3.Dot(n, eye - p0) < 0f) b++; else f++;   // N·V < 0 -> back face
                }
            }
            frontTris = f; backTris = b;
        }

        void SetStress(bool on)
        {
            stress = on;
            if (stressRoot != null) Destroy(stressRoot);
            if (!on) return;
            stressRoot = new GameObject("Stress Test (2500 objects)");
            stressRoot.transform.SetParent(transform, false);
            var b = new FlatMeshBuilder(); b.AddBox(Vector3.zero, Vector3.one * 0.3f, Quaternion.identity);
            Mesh m = b.ToMesh("StressBox");
            for (int i = 0; i < 2500; i++)
            {
                var go = MakeObj("s" + i, m, matPart, stressRoot.transform);
                go.transform.localPosition = new Vector3(Random.Range(-25f, 25f), Random.Range(0.2f, 6f), Random.Range(-25f, 25f));
                go.transform.localRotation = Random.rotation;
            }
        }

        // =================================================================== GUI
        void EnsureStyles()
        {
            if (hStyle != null) return;
            hStyle = new GUIStyle(GUI.skin.label) { fontSize = 15, fontStyle = FontStyle.Bold, richText = true, wordWrap = true };
            txtStyle = new GUIStyle(GUI.skin.label) { fontSize = 13, richText = true, wordWrap = true };
            smallStyle = new GUIStyle(GUI.skin.label) { fontSize = 12, richText = true, wordWrap = true };
            monoStyle = new GUIStyle(GUI.skin.label) { fontSize = 13, richText = true, wordWrap = false };
            Font mono = null;
            try { mono = Font.CreateDynamicFontFromOSFont(new[] { "Consolas", "Courier New", "DejaVu Sans Mono", "Menlo" }, 13); } catch { mono = null; }
            if (mono != null) monoStyle.font = mono;
            boxStyle = new GUIStyle(GUI.skin.box) { padding = new RectOffset(10, 10, 8, 8) };
            var bg = new Texture2D(1, 1); bg.SetPixel(0, 0, new Color(0.05f, 0.06f, 0.08f, 0.88f)); bg.Apply();
            boxStyle.normal.background = bg;
        }

        void HandleInput()
        {
            Event e = Event.current;
            if (e == null) return;
            Vector2 mp = e.mousePosition;                 // raw pixels (GUI.matrix not yet applied)
            bool overPanel = panelVisible && panelRectPx.Contains(mp);
            bool overTopBar = mp.y < 44f * guiScale;

            if (e.type == EventType.KeyDown)
            {
                switch (e.keyCode)
                {
                    case KeyCode.Alpha1: SetMode(Mode.CadMesh); e.Use(); break;
                    case KeyCode.Alpha2: SetMode(Mode.Transformations); e.Use(); break;
                    case KeyCode.Alpha3: SetMode(Mode.Clip2D); e.Use(); break;
                    case KeyCode.Alpha4: SetMode(Mode.HiddenSurface); e.Use(); break;
                    case KeyCode.Alpha5: SetMode(Mode.StereoVR); e.Use(); break;
                    case KeyCode.H: panelVisible = !panelVisible; e.Use(); break;
                    case KeyCode.W: wireframe = !wireframe; e.Use(); break;
                }
            }
            if (mode == Mode.Clip2D) return;
            if (e.type == EventType.MouseDown && !overPanel && !overTopBar) draggingCamera = true;
            if (e.rawType == EventType.MouseUp) draggingCamera = false;
            if (e.type == EventType.MouseDrag && draggingCamera)
            {
                yaw += e.delta.x * 0.3f;
                pitch += e.delta.y * 0.3f;
                e.Use();
            }
            if (e.type == EventType.ScrollWheel && !overPanel)
            {
                dist *= 1f + e.delta.y * 0.04f;
                e.Use();
            }
        }

        void OnGUI()
        {
            if (phongShader == null) return;
            guiScale = Mathf.Clamp(Screen.height / 900f, 0.8f, 2.5f);
            float vw = Screen.width / guiScale, vh = Screen.height / guiScale;
            float panelW = Mathf.Min(450f, vw * 0.42f);
            panelRectPx = new Rect(6f * guiScale, 46f * guiScale, panelW * guiScale, (vh - 80f) * guiScale);
            HandleInput();
            EnsureStyles();
            GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(guiScale, guiScale, 1f));

            // top bar
            GUILayout.BeginArea(new Rect(6, 6, vw - 12, 36));
            GUILayout.BeginHorizontal();
            for (int i = 0; i < ModeNames.Length; i++)
            {
                GUI.color = (int)mode == i ? new Color(1f, 0.85f, 0.3f) : Color.white;
                if (GUILayout.Button(ModeNames[i], GUILayout.Height(30))) SetMode((Mode)i);
            }
            GUI.color = Color.white;
            if (GUILayout.Button(panelVisible ? "Hide panel (H)" : "Show panel (H)", GUILayout.Height(30), GUILayout.Width(130))) panelVisible = !panelVisible;
            GUILayout.EndHorizontal();
            GUILayout.EndArea();

            if (mode == Mode.Clip2D) DrawClipLabels();
            if (mode == Mode.StereoVR)
            {
                GUI.Label(new Rect(vw * 0.25f - 60, vh - 60, 160, 24), "<b>LEFT EYE</b>", hStyle);
                GUI.Label(new Rect(vw * 0.75f - 60, vh - 60, 160, 24), "<b>RIGHT EYE</b>", hStyle);
                GUI.Box(new Rect(vw * 0.5f - 1, 44, 2, vh - 44), GUIContent.none);
            }
            if (mode == Mode.HiddenSurface)
                GUI.Label(new Rect(vw * 0.70f, vh * 0.58f - 24, vw * 0.29f, 24), "<b>Observer (top view): yellow = headset frustum, green = drawn, red = culled</b>", smallStyle);

            if (panelVisible)
            {
                GUILayout.BeginArea(new Rect(6, 46, panelW, vh - 80), boxStyle);
                scroll = GUILayout.BeginScrollView(scroll);
                switch (mode)
                {
                    case Mode.CadMesh: PanelCad(); break;
                    case Mode.Transformations: PanelTransform(); break;
                    case Mode.Clip2D: PanelClip(); break;
                    case Mode.HiddenSurface: PanelHidden(); break;
                    case Mode.StereoVR: PanelStereo(); break;
                }
                GUILayout.EndScrollView();
                GUILayout.EndArea();
            }
            GUI.Label(new Rect(vw - 520, vh - 28, 514, 24),
                "Drag = orbit · Wheel = zoom · 1–5 = modes · W = wireframe · H = panel   |   " + (1000f * avgDt).ToString("0.0") + " ms  (" + (1f / avgDt).ToString("0") + " FPS)", smallStyle);
        }

        // ------------------------------------------------------------------ panels
        void PanelCad()
        {
            GUILayout.Label("Q1  Geometric modelling: 2-D CAD → 3-D mesh", hStyle);
            GUILayout.Label("The body is a <b>sweep (extrusion)</b> of the 2-D side profile (yellow). Wheels are <b>surfaces of revolution (lathe)</b>; spokes are box primitives. " +
                            "Together they form a <b>boundary representation (B-rep)</b>: faces, edges, vertices. The car is a CSG-style union: Car = Body ∪ 4×(Rim ∪ Tyre).", txtStyle);
            GUILayout.Space(6);
            GUILayout.Label("Extrusion depth: " + (extrude * CarWidth).ToString("0.00") + " m  (" + (extrude * 100f).ToString("0") + " %)", txtStyle);
            extrude = GUILayout.HorizontalSlider(extrude, 0.01f, 1f);
            GUILayout.Space(8);
            GUILayout.Label("Lathe segments n = " + latheSegments, txtStyle);
            latheSegments = Mathf.RoundToInt(GUILayout.HorizontalSlider(latheSegments, 6, 128));
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("n = 8")) latheSegments = 8;
            if (GUILayout.Button("n = 32")) latheSegments = 32;
            if (GUILayout.Button("n = 104")) latheSegments = 104;
            GUILayout.EndHorizontal();
            float err = 216f * (1f - Mathf.Cos(Mathf.PI / latheSegments));
            GUILayout.Label("Chordal error on a 216 mm rim: e = r(1 − cos(π/n)) = <b>" + err.ToString("0.000") + " mm</b>" +
                            (err <= 0.1f ? "  <color=#7CFC00>(≤ 0.1 mm CAD tolerance)</color>" : "  <color=#FF8080>(> 0.1 mm tolerance)</color>"), txtStyle);
            GUILayout.Space(6);
            wireframe = GUILayout.Toggle(wireframe, " Wireframe overlay (W)");
            showProfile = GUILayout.Toggle(showProfile, " Show 2-D CAD profile");
            explode = GUILayout.Toggle(explode, " Exploded view (CSG primitives)");
            GUILayout.Space(8);
            GUILayout.Label("B-rep statistics (welded)", hStyle);
            GUILayout.Label(StatLine("Body", bodyStats) + "\n" + StatLine("Rim", rimStats) + "\n" + StatLine("Tyre", tireStats), monoStyle);
            GUILayout.Label("Euler: closed genus-0 shell → V − E + F = 2; torus (tyre, rim barrel) → 0. Rim = barrel(0) + hub(2) + 5 spokes(2 each) = 12.", smallStyle);
            GUILayout.Label("Total car triangles: <b>" + carTriangles + "</b>", txtStyle);
        }

        static string StatLine(string n, MeshKit.BRepStats s)
        {
            return n.PadRight(5) + " V=" + s.V.ToString().PadLeft(5) + "  E=" + s.E.ToString().PadLeft(5) + "  F=" + s.F.ToString().PadLeft(5) + "  χ=" + s.Chi;
        }

        void PanelTransform()
        {
            GUILayout.Label("Q2  Composite transformation  M = T · R · S", hStyle);
            GUILayout.Label("Units: mm. Unity convention: left-handed, Y up, Z forward, column vectors (P' = M·P). Rim axle = X. " +
                            "S = uniform scale 1.5, R = 45° about Y, T = +50 mm along Z. Grey wireframe = original rim, yellow cube = P, red cube = P'.", txtStyle);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button(correctOrder ? "Order: T·R·S (correct)" : "Order: S·R·T (wrong)")) { correctOrder = !correctOrder; stageT = 0; stageTarget = 0; }
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Reset")) { stageT = 0; stageTarget = 0; }
            if (GUILayout.Button(correctOrder ? "1: S" : "1: T")) stageTarget = 1;
            if (GUILayout.Button("2: R")) stageTarget = 2;
            if (GUILayout.Button(correctOrder ? "3: T" : "3: S")) stageTarget = 3;
            if (GUILayout.Button("Animate ▶")) { stageT = 0; stageTarget = 3; }
            GUILayout.EndHorizontal();
            GUILayout.Label("Stage t = " + stageT.ToString("0.00") + " / 3", smallStyle);

            float s, ang, tz; StageValues(out s, out ang, out tz);
            Matrix4x4 S = MScale(s), R = MRotY(ang), T = MTrans(0, 0, tz);
            Matrix4x4 M = CurrentM();
            GUILayout.Label("S(" + s.ToString("0.00") + ")\n" + Fmt(S), monoStyle);
            GUILayout.Label("R_y(" + ang.ToString("0.0") + "°)\n" + Fmt(R), monoStyle);
            GUILayout.Label("T(0, 0, " + tz.ToString("0.0") + ")\n" + Fmt(T), monoStyle);
            GUILayout.Label("<b>M (hand product, " + (correctOrder ? "T·R·S" : "S·R·T") + ")</b>\n" + Fmt(M), monoStyle);

            Matrix4x4 trs = Matrix4x4.TRS(new Vector3(0, 0, tz), Quaternion.Euler(0, ang, 0), Vector3.one * s);
            Matrix4x4 actual = Matrix4x4.TRS(rimT.localPosition, rimT.localRotation, rimT.localScale);
            float diff = 0f, diffTrs = 0f;
            for (int i = 0; i < 16; i++) { diff = Mathf.Max(diff, Mathf.Abs(M[i] - actual[i])); diffTrs = Mathf.Max(diffTrs, Mathf.Abs(M[i] - trs[i])); }
            GUILayout.Label("<b>Unity Matrix4x4.TRS(t, R, s)</b>\n" + Fmt(trs), monoStyle);
            GUILayout.Label("max |M − TRS| = " + diffTrs.ToString("0.000000") + (correctOrder ? "  → identical (Unity uses T·R·S)" : "  → differs: order matters"), txtStyle);
            GUILayout.Label("max |M − rim.localToParent| = " + diff.ToString("0.000000"), smallStyle);

            Vector3 pHand = M.MultiplyPoint3x4(TestPointMM);
            Vector3 pScene = mmSpace.InverseTransformPoint(markerT.position);
            GUILayout.Label("P  = (0, 0, 216, 1)ᵀ\nP' = M·P  = (" + V3(pHand) + ")\nP' scene  = (" + V3(pScene) + ")", monoStyle);
            GUILayout.Label("det(3×3 part) = " + (s * s * s).ToString("0.000") + "  (volume ×" + (s * s * s).ToString("0.000") + ")", smallStyle);
        }

        static string V3(Vector3 v) { return v.x.ToString("0.00") + ", " + v.y.ToString("0.00") + ", " + v.z.ToString("0.00"); }

        static string Fmt(Matrix4x4 m)
        {
            var sb = new StringBuilder();
            for (int r = 0; r < 4; r++)
            {
                sb.Append("| ");
                for (int c = 0; c < 4; c++) sb.Append(m[r, c].ToString("0.0000").PadLeft(9)).Append(' ');
                sb.Append('|');
                if (r < 3) sb.Append('\n');
            }
            return sb.ToString();
        }

        void PanelClip()
        {
            GUILayout.Label("Q3a  Clipping (Module 2)", hStyle);
            GUILayout.Label("Window: x ∈ [100, 400], y ∈ [100, 300]. Region code bits = T B R L. Red = original segment, green = visible part after clipping. " +
                            "Orange triangle = input polygon, yellow = Sutherland–Hodgman output.", txtStyle);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button(useLiangBarsky ? "Algorithm: Liang–Barsky" : "Algorithm: Cohen–Sutherland")) { useLiangBarsky = !useLiangBarsky; clipDirty = true; }
            bool sp = GUILayout.Toggle(showPolygon, " Polygon (S–H)");
            if (sp != showPolygon) { showPolygon = sp; clipDirty = true; }
            GUILayout.EndHorizontal();
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Report examples")) ReportLines();
            if (GUILayout.Button("Random lines")) RandomLines();
            GUILayout.EndHorizontal();
            GUILayout.Label("Trace line:", txtStyle);
            GUILayout.BeginHorizontal();
            for (int i = 0; i < clipLines.Count; i++)
            {
                GUI.color = i == selectedLine ? new Color(1f, 0.85f, 0.3f) : Color.white;
                if (GUILayout.Button("L" + (i + 1))) { selectedLine = i; clipDirty = true; }
            }
            GUI.color = Color.white;
            GUILayout.EndHorizontal();
            if (selectedLine < clipLines.Count)
            {
                Vector2 a = clipLines[selectedLine][0], b = clipLines[selectedLine][1];
                GUILayout.Label("L" + (selectedLine + 1) + ": (" + a.x + ", " + a.y + ") → (" + b.x + ", " + b.y + ")", txtStyle);
            }
            GUILayout.Label(clipTrace, monoStyle);
            if (showPolygon)
            {
                GUILayout.Label("Sutherland–Hodgman trace", hStyle);
                GUILayout.Label(polyTrace, smallStyle);
            }
        }

        void DrawClipLabels()
        {
            string[] codes = { "1001", "1000", "1010", "0001", "0000", "0010", "0101", "0100", "0110" };
            float[] xs = { 50, 250, 450 }, ys = { 350, 200, 50 };
            for (int r = 0; r < 3; r++)
                for (int c = 0; c < 3; c++)
                {
                    Vector2 g = ClipToGui(new Vector2(xs[c], ys[r] + (r == 1 && c == 1 ? 80 : 0)));
                    GUI.Label(new Rect(g.x - 22, g.y - 10, 60, 20), "<color=#8899AA>" + codes[r * 3 + c] + "</color>", smallStyle);
                }
            for (int i = 0; i < clipLines.Count; i++)
            {
                Vector2 g = ClipToGui(clipLines[i][0]);
                GUI.Label(new Rect(g.x - 30, g.y - 22, 140, 20), "<color=#FF9090>L" + (i + 1) + " " + Clipping.Bits(Clipping.OutCode(clipLines[i][0], ClipWin)) + "</color>", smallStyle);
                Vector2 g2 = ClipToGui(clipLines[i][1]);
                GUI.Label(new Rect(g2.x + 6, g2.y - 4, 80, 20), "<color=#FF9090>" + Clipping.Bits(Clipping.OutCode(clipLines[i][1], ClipWin)) + "</color>", smallStyle);
            }
            Vector2 w0 = ClipToGui(new Vector2(ClipWin.xMin, ClipWin.yMin)), w1 = ClipToGui(new Vector2(ClipWin.xMax, ClipWin.yMax));
            GUI.Label(new Rect(w0.x - 40, w0.y + 2, 110, 20), "(100,100)", smallStyle);
            GUI.Label(new Rect(w1.x - 20, w1.y - 20, 110, 20), "(400,300)", smallStyle);
        }

        void PanelHidden()
        {
            GUILayout.Label("Q3b  Hidden-surface removal & culling", hStyle);
            GUILayout.Label("Back-face culling (Cull mode)", txtStyle);
            GUILayout.BeginHorizontal();
            string[] cn = { "Off", "Front", "Back" };
            for (int i = 0; i < 3; i++)
            {
                GUI.color = cullMode == i ? new Color(1f, 0.85f, 0.3f) : Color.white;
                if (GUILayout.Button("Cull " + cn[i])) { cullMode = i; ApplyCull(i); }
            }
            GUI.color = Color.white;
            GUILayout.EndHorizontal();
            int tot = Mathf.Max(1, frontTris + backTris);
            GUILayout.Label("Car triangles: " + tot + "   front-facing: <b>" + frontTris + "</b>   back-facing (N·V < 0): <b>" + backTris +
                            "</b> (" + (100f * backTris / tot).ToString("0.0") + " % skipped by back-face culling)", txtStyle);
            GUILayout.Space(4);
            sectionOn = GUILayout.Toggle(sectionOn, " Section plane x = d (clips the car, exposes back faces)");
            GUILayout.Label("d = " + sectionD.ToString("0.00") + " m", smallStyle);
            sectionD = GUILayout.HorizontalSlider(sectionD, -1.2f, 1.2f);
            GUILayout.Label("With Cull Off, back faces seen through the cut are painted <color=#FF55FF>magenta</color>; with Cull Back they disappear.", smallStyle);
            GUILayout.Space(4);
            depthView = GUILayout.Toggle(depthView, " Z-buffer view (white = near, black = far)");
            GUILayout.Label("Near plane n = " + nearPlane.ToString("0.00") + " m", smallStyle);
            nearPlane = GUILayout.HorizontalSlider(nearPlane, 0.01f, 8f);
            GUILayout.Label("Far plane f = " + farPlane.ToString("0.0") + " m", smallStyle);
            farPlane = GUILayout.HorizontalSlider(farPlane, 5f, 80f);
            GUILayout.Label("f/n = " + (farPlane / nearPlane).ToString("0") + "  (smaller ratio → better depth precision)", smallStyle);
            GUILayout.Space(4);
            wireframe = GUILayout.Toggle(wireframe, " Wireframe overlay (W)");
            GUILayout.Space(6);
            GUILayout.Label("View-frustum culling (AABB vs 6 planes)", hStyle);
            GUILayout.Label("Studio objects drawn: <b>" + visibleParts + " / " + parts.Count + "</b>   triangles: " + visiblePartTris + " / " + totalPartTris +
                            "\nCulled before the GPU: <b>" + (parts.Count - visibleParts) + "</b> objects (" + (100f * (parts.Count - visibleParts) / Mathf.Max(1, parts.Count)).ToString("0") + " %)", txtStyle);
            GUILayout.Label("Orbit the camera and watch green/red change in the observer view (bottom-right).", smallStyle);
        }

        void PanelStereo()
        {
            GUILayout.Label("Dual-display (stereo) rendering", hStyle);
            GUILayout.Label("Two cameras separated by the IPD render the same scene into the left and right halves – the two HMD displays. Every visible triangle is processed twice.", txtStyle);
            GUILayout.Label("IPD = " + ipdMM.ToString("0") + " mm", txtStyle);
            ipdMM = GUILayout.HorizontalSlider(ipdMM, 54f, 74f);
            float ms = avgDt * 1000f;
            GUILayout.Label("Frame time: <b>" + ms.ToString("0.00") + " ms</b>  (" + (1f / avgDt).ToString("0") + " FPS)\n90 Hz budget: <b>11.11 ms</b> → " +
                            (ms <= 11.11f ? "<color=#7CFC00>within budget</color>" : "<color=#FF8080>over budget – reprojection / dropped frames</color>"), txtStyle);
            int bar = Mathf.Clamp(Mathf.RoundToInt(ms / 11.11f * 20f), 0, 40);
            GUILayout.Label("[" + new string('|', Mathf.Min(bar, 20)) + new string('.', Mathf.Max(0, 20 - bar)) + "]" + (bar > 20 ? new string('!', bar - 20) : ""), monoStyle);
            bool st = GUILayout.Toggle(stress, " Stress test: +2500 objects");
            if (st != stress) SetStress(st);
            GUILayout.Space(8);
            GUILayout.Label("Bengaluru ⇄ Detroit collaboration", hStyle);
            GUILayout.Label("Great-circle distance ≈ 13 555 km → light-in-fibre RTT ≥ 136 ms (real Internet ≈ 250–300 ms). " +
                            "Each site renders locally at 90 Hz; only small state messages travel, so latency affects <i>edits</i>, not head-motion-to-photon.", txtStyle);
            GUILayout.Label("Network RTT = " + rttMS.ToString("0") + " ms  (one-way " + (rttMS * 0.5f).ToString("0") + " ms)", txtStyle);
            rttMS = GUILayout.HorizontalSlider(rttMS, 0f, 400f);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("Bengaluru rotates +45° (local)")) { turntableTarget += 45f; netLog = "Local edit applied immediately"; }
            if (GUILayout.Button("Detroit rotates +45° (remote)"))
            {
                NetCmd c; c.arrive = Time.time + rttMS * 0.0005f; c.delta = 45f; inFlight.Add(c);
                netLog = "Remote command sent – arrives in " + (rttMS * 0.5f).ToString("0") + " ms";
            }
            GUILayout.EndHorizontal();
            GUILayout.Label(netLog + (inFlight.Count > 0 ? "   (" + inFlight.Count + " in flight)" : ""), smallStyle);
            GUILayout.Label("Orange avatar (Detroit) is drawn at its pose from " + (rttMS * 0.5f).ToString("0") + " ms ago; blue avatar = local designer.", smallStyle);
        }
    }
}
