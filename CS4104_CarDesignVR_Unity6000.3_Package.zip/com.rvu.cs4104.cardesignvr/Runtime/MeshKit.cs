using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace CS4104
{
    /// <summary>
    /// Builds flat-shaded triangle meshes. Every triangle gets its own three
    /// vertices so the face normal is exact (flat shading) and faceting from a
    /// low tessellation level is clearly visible.
    /// Winding is fixed automatically: Unity treats a triangle as FRONT-facing
    /// when Cross(b - a, c - a) points towards the viewer (clockwise winding in
    /// a left-handed system), so AddTri swaps b and c whenever that cross
    /// product disagrees with the desired outward normal.
    /// </summary>
    public class FlatMeshBuilder
    {
        public readonly List<Vector3> V = new List<Vector3>();
        public readonly List<Vector3> N = new List<Vector3>();
        public readonly List<int> I = new List<int>();

        public void AddTri(Vector3 a, Vector3 b, Vector3 c, Vector3 desiredNormal)
        {
            Vector3 n = Vector3.Cross(b - a, c - a);
            if (n.sqrMagnitude < 1e-14f) return;                 // degenerate (e.g. on the lathe axis)
            if (Vector3.Dot(n, desiredNormal) < 0f) { Vector3 t = b; b = c; c = t; n = -n; }
            n.Normalize();
            int k = V.Count;
            V.Add(a); V.Add(b); V.Add(c);
            N.Add(n); N.Add(n); N.Add(n);
            I.Add(k); I.Add(k + 1); I.Add(k + 2);
        }

        public void AddQuad(Vector3 a, Vector3 b, Vector3 c, Vector3 d, Vector3 desiredNormal)
        {
            AddTri(a, b, c, desiredNormal);
            AddTri(a, c, d, desiredNormal);
        }

        /// <summary>Oriented box (6 faces, 12 triangles).</summary>
        public void AddBox(Vector3 center, Vector3 size, Quaternion rot)
        {
            Vector3 hx = rot * new Vector3(size.x * 0.5f, 0, 0);
            Vector3 hy = rot * new Vector3(0, size.y * 0.5f, 0);
            Vector3 hz = rot * new Vector3(0, 0, size.z * 0.5f);
            Vector3[] p = new Vector3[8];
            for (int i = 0; i < 8; i++)
            {
                float sx = (i & 1) == 0 ? -1 : 1, sy = (i & 2) == 0 ? -1 : 1, sz = (i & 4) == 0 ? -1 : 1;
                p[i] = center + sx * hx + sy * hy + sz * hz;
            }
            AddQuad(p[1], p[3], p[7], p[5], hx);   // +x
            AddQuad(p[0], p[2], p[6], p[4], -hx);  // -x
            AddQuad(p[2], p[3], p[7], p[6], hy);   // +y
            AddQuad(p[0], p[1], p[5], p[4], -hy);  // -y
            AddQuad(p[4], p[5], p[7], p[6], hz);   // +z
            AddQuad(p[0], p[1], p[3], p[2], -hz);  // -z
        }

        public Mesh ToMesh(string name)
        {
            var m = new Mesh { name = name };
            if (V.Count > 65000) m.indexFormat = IndexFormat.UInt32;
            m.SetVertices(V);
            m.SetNormals(N);
            m.SetTriangles(I, 0);
            m.RecalculateBounds();
            return m;
        }
    }

    /// <summary>Procedural geometry: extrusion, lathe (surface of revolution), wheel rim, car body, line meshes.</summary>
    public static class MeshKit
    {
        // ------------------------------------------------------------------ 2-D helpers
        /// <summary>Shoelace formula: positive = counter-clockwise polygon.</summary>
        public static float SignedArea(IList<Vector2> poly)
        {
            double a = 0;
            for (int i = 0; i < poly.Count; i++)
            {
                Vector2 p = poly[i], q = poly[(i + 1) % poly.Count];
                a += (double)p.x * q.y - (double)q.x * p.y;
            }
            return (float)(0.5 * a);
        }

        static float Cross2(Vector2 o, Vector2 a, Vector2 b)
        {
            return (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
        }

        static bool PointInTri(Vector2 p, Vector2 a, Vector2 b, Vector2 c)
        {
            float d1 = Cross2(a, b, p), d2 = Cross2(b, c, p), d3 = Cross2(c, a, p);
            bool hasNeg = d1 < 0 || d2 < 0 || d3 < 0;
            bool hasPos = d1 > 0 || d2 > 0 || d3 > 0;
            return !(hasNeg && hasPos);
        }

        /// <summary>Ear-clipping triangulation of a simple CCW polygon. Returns index triples.</summary>
        public static List<int> Triangulate(IList<Vector2> poly)
        {
            var result = new List<int>();
            var idx = new List<int>();
            for (int i = 0; i < poly.Count; i++) idx.Add(i);
            int guard = 0;
            while (idx.Count > 3 && guard++ < 10000)
            {
                bool clipped = false;
                for (int i = 0; i < idx.Count; i++)
                {
                    int i0 = idx[(i + idx.Count - 1) % idx.Count], i1 = idx[i], i2 = idx[(i + 1) % idx.Count];
                    Vector2 a = poly[i0], b = poly[i1], c = poly[i2];
                    if (Cross2(a, b, c) <= 1e-9f) continue;            // reflex or collinear vertex
                    bool ear = true;
                    for (int j = 0; j < idx.Count && ear; j++)
                    {
                        int t = idx[j];
                        if (t == i0 || t == i1 || t == i2) continue;
                        if (PointInTri(poly[t], a, b, c)) ear = false;
                    }
                    if (!ear) continue;
                    result.Add(i0); result.Add(i1); result.Add(i2);
                    idx.RemoveAt(i);
                    clipped = true;
                    break;
                }
                if (!clipped) break;                                     // numerical fallback
            }
            if (idx.Count == 3) { result.Add(idx[0]); result.Add(idx[1]); result.Add(idx[2]); }
            return result;
        }

        // ------------------------------------------------------------------ extrusion (sweep of a 2-D CAD profile)
        /// <summary>
        /// Extrudes a side-view profile given in (u = z, v = y) along X from -width/2 to +width/2.
        /// Side walls are quads, the two caps are ear-clipped. This is the B-rep of a prism.
        /// </summary>
        public static Mesh Extrude(List<Vector2> profileZY, float width, string name)
        {
            var poly = new List<Vector2>(profileZY);
            if (SignedArea(poly) < 0) poly.Reverse();                   // force CCW
            var b = new FlatMeshBuilder();
            float h = Mathf.Max(width, 0.002f) * 0.5f;
            for (int i = 0; i < poly.Count; i++)
            {
                Vector2 p = poly[i], q = poly[(i + 1) % poly.Count];
                Vector2 d = q - p;
                Vector3 outward = new Vector3(0, -d.x, d.y);              // CCW outward normal (dv,-du) mapped to (y,z)
                b.AddQuad(new Vector3(-h, p.y, p.x), new Vector3(h, p.y, p.x),
                          new Vector3(h, q.y, q.x), new Vector3(-h, q.y, q.x), outward);
            }
            List<int> tris = Triangulate(poly);
            for (int t = 0; t < tris.Count; t += 3)
            {
                Vector2 a = poly[tris[t]], c1 = poly[tris[t + 1]], c2 = poly[tris[t + 2]];
                b.AddTri(new Vector3(h, a.y, a.x), new Vector3(h, c1.y, c1.x), new Vector3(h, c2.y, c2.x), Vector3.right);
                b.AddTri(new Vector3(-h, a.y, a.x), new Vector3(-h, c1.y, c1.x), new Vector3(-h, c2.y, c2.x), Vector3.left);
            }
            return b.ToMesh(name);
        }

        // ------------------------------------------------------------------ lathe (surface of revolution)
        /// <summary>
        /// Revolves a closed profile given in (x = axial, y = radius) around the X axis.
        /// Point (x, r) at angle t maps to (x, r cos t, r sin t).
        /// </summary>
        public static void Lathe(FlatMeshBuilder b, List<Vector2> profileXR, int segments, float scale)
        {
            var poly = new List<Vector2>(profileXR);
            bool ccw = SignedArea(poly) > 0;
            segments = Mathf.Max(3, segments);
            for (int s = 0; s < segments; s++)
            {
                float t0 = 2f * Mathf.PI * s / segments, t1 = 2f * Mathf.PI * (s + 1) / segments, tm = 0.5f * (t0 + t1);
                float c0 = Mathf.Cos(t0), s0 = Mathf.Sin(t0), c1 = Mathf.Cos(t1), s1 = Mathf.Sin(t1);
                for (int i = 0; i < poly.Count; i++)
                {
                    Vector2 p = poly[i], q = poly[(i + 1) % poly.Count];
                    Vector2 d = q - p;
                    Vector2 n2 = ccw ? new Vector2(d.y, -d.x) : new Vector2(-d.y, d.x);
                    Vector3 outward = new Vector3(n2.x, n2.y * Mathf.Cos(tm), n2.y * Mathf.Sin(tm));
                    Vector3 p0 = new Vector3(p.x, p.y * c0, p.y * s0) * scale;
                    Vector3 q0 = new Vector3(q.x, q.y * c0, q.y * s0) * scale;
                    Vector3 q1 = new Vector3(q.x, q.y * c1, q.y * s1) * scale;
                    Vector3 p1 = new Vector3(p.x, p.y * c1, p.y * s1) * scale;
                    b.AddQuad(p0, q0, q1, p1, outward);
                }
            }
        }

        /// <summary>17-inch wheel rim (radius 0.216 m): barrel + hub (lathe) + 5 spokes (boxes). Axle = local X, outer face = +X.</summary>
        public static Mesh Rim(int segments, float scale, string name)
        {
            var b = new FlatMeshBuilder();
            Lathe(b, new List<Vector2> { new Vector2(-0.105f, 0.190f), new Vector2(0.105f, 0.190f),
                                          new Vector2(0.105f, 0.216f), new Vector2(0.090f, 0.216f),
                                          new Vector2(0.090f, 0.205f), new Vector2(-0.090f, 0.205f),
                                          new Vector2(-0.090f, 0.216f), new Vector2(-0.105f, 0.216f) }, segments, scale);
            Lathe(b, new List<Vector2> { new Vector2(0.030f, 0.0f), new Vector2(0.085f, 0.0f),
                                          new Vector2(0.085f, 0.055f), new Vector2(0.030f, 0.065f) }, segments, scale);
            for (int k = 0; k < 5; k++)
            {
                Quaternion q = Quaternion.AngleAxis(72f * k, Vector3.right);
                Vector3 c = q * new Vector3(0.065f, 0.125f, 0f);
                b.AddBox(c * scale, new Vector3(0.03f, 0.14f, 0.045f) * scale, q);
            }
            return b.ToMesh(name);
        }

        public static Mesh Tire(int segments, string name)
        {
            var b = new FlatMeshBuilder();
            Lathe(b, new List<Vector2> { new Vector2(-0.12f, 0.214f), new Vector2(0.12f, 0.214f),
                                          new Vector2(0.125f, 0.29f), new Vector2(0.10f, 0.33f),
                                          new Vector2(-0.10f, 0.33f), new Vector2(-0.125f, 0.29f) }, segments, 1f);
            return b.ToMesh(name);
        }

        /// <summary>Sedan side profile (z = length, y = height) with two wheel arches, metres.</summary>
        public static List<Vector2> CarProfile()
        {
            var p = new List<Vector2>();
            p.Add(new Vector2(-2.30f, 0.30f));
            AddArch(p, -1.40f);
            AddArch(p, 1.40f);
            p.Add(new Vector2(2.30f, 0.30f));
            p.Add(new Vector2(2.36f, 0.55f));
            p.Add(new Vector2(2.28f, 0.80f));
            p.Add(new Vector2(1.15f, 0.96f));
            p.Add(new Vector2(0.50f, 1.40f));
            p.Add(new Vector2(-0.70f, 1.44f));
            p.Add(new Vector2(-1.70f, 1.05f));
            p.Add(new Vector2(-2.28f, 0.98f));
            p.Add(new Vector2(-2.36f, 0.62f));
            return p;
        }

        static void AddArch(List<Vector2> p, float zc)
        {
            const float yc = 0.33f, r = 0.40f;
            float a0 = Mathf.Asin((0.30f - yc) / r);                     // where the arch meets the sill line
            int steps = 14;
            for (int i = 0; i <= steps; i++)
            {
                float a = Mathf.PI - a0 - (Mathf.PI - 2f * a0) * i / steps;  // from rear side, over the top, to front side
                p.Add(new Vector2(zc + r * Mathf.Cos(a), yc + r * Mathf.Sin(a)));
            }
        }

        // ------------------------------------------------------------------ B-rep statistics
        public struct BRepStats { public int V, E, F, Chi; }

        /// <summary>Welds coincident vertices then counts V, E, F and the Euler characteristic V - E + F.</summary>
        public static BRepStats Stats(Mesh m)
        {
            Vector3[] v = m.vertices; int[] t = m.triangles;
            var map = new Dictionary<Vector3Int, int>();
            int[] weld = new int[v.Length];
            for (int i = 0; i < v.Length; i++)
            {
                var key = new Vector3Int(Mathf.RoundToInt(v[i].x * 1e4f), Mathf.RoundToInt(v[i].y * 1e4f), Mathf.RoundToInt(v[i].z * 1e4f));
                int id;
                if (!map.TryGetValue(key, out id)) { id = map.Count; map.Add(key, id); }
                weld[i] = id;
            }
            var edges = new HashSet<long>();
            int faces = 0;
            for (int i = 0; i < t.Length; i += 3)
            {
                int a = weld[t[i]], b = weld[t[i + 1]], c = weld[t[i + 2]];
                if (a == b || b == c || a == c) continue;
                faces++;
                edges.Add(EdgeKey(a, b)); edges.Add(EdgeKey(b, c)); edges.Add(EdgeKey(c, a));
            }
            BRepStats s; s.V = map.Count; s.E = edges.Count; s.F = faces; s.Chi = s.V - s.E + s.F;
            return s;
        }

        static long EdgeKey(int a, int b) { return a < b ? ((long)a << 32) | (uint)b : ((long)b << 32) | (uint)a; }

        // ------------------------------------------------------------------ line meshes
        /// <summary>Unique-edge wireframe of a triangle mesh (MeshTopology.Lines).</summary>
        public static Mesh Wireframe(Mesh src, Color col)
        {
            Vector3[] v = src.vertices; int[] t = src.triangles;
            var map = new Dictionary<Vector3Int, int>();
            var pos = new List<Vector3>();
            int[] weld = new int[v.Length];
            for (int i = 0; i < v.Length; i++)
            {
                var key = new Vector3Int(Mathf.RoundToInt(v[i].x * 1e4f), Mathf.RoundToInt(v[i].y * 1e4f), Mathf.RoundToInt(v[i].z * 1e4f));
                int id;
                if (!map.TryGetValue(key, out id)) { id = pos.Count; map.Add(key, id); pos.Add(v[i]); }
                weld[i] = id;
            }
            var seen = new HashSet<long>();
            var lb = new LineBuilder();
            for (int i = 0; i < t.Length; i += 3)
                for (int e = 0; e < 3; e++)
                {
                    int a = weld[t[i + e]], b = weld[t[i + (e + 1) % 3]];
                    if (a == b) continue;
                    if (seen.Add(EdgeKey(a, b))) lb.Add(pos[a], pos[b], col);
                }
            return lb.ToMesh("Wireframe_" + src.name);
        }
    }

    /// <summary>Collects coloured line segments into a MeshTopology.Lines mesh.</summary>
    public class LineBuilder
    {
        readonly List<Vector3> v = new List<Vector3>();
        readonly List<Color> c = new List<Color>();
        public void Add(Vector3 a, Vector3 b, Color col) { v.Add(a); v.Add(b); c.Add(col); c.Add(col); }
        public void Clear() { v.Clear(); c.Clear(); }
        public Mesh ToMesh(string name) { var m = new Mesh { name = name }; Fill(m); return m; }
        public void Fill(Mesh m)
        {
            m.Clear();
            if (v.Count > 65000) m.indexFormat = IndexFormat.UInt32;
            m.SetVertices(v);
            m.SetColors(c);
            var idx = new int[v.Count];
            for (int i = 0; i < idx.Length; i++) idx[i] = i;
            m.SetIndices(idx, MeshTopology.Lines, 0);
            m.RecalculateBounds();
        }
    }

    /// <summary>Thick 2-D lines and markers as coloured quads (lines thicker than 1 px for the clipping figure).</summary>
    public class QuadLineBuilder
    {
        readonly List<Vector3> v = new List<Vector3>();
        readonly List<Color> c = new List<Color>();
        readonly List<int> t = new List<int>();

        public void Clear() { v.Clear(); c.Clear(); t.Clear(); }

        public void Line(Vector2 a, Vector2 b, float width, Color col, float z)
        {
            Vector2 d = b - a;
            if (d.sqrMagnitude < 1e-10f) return;
            Vector2 n = new Vector2(-d.y, d.x).normalized * width * 0.5f;
            Quad(a + n, b + n, b - n, a - n, col, z);
        }

        public void Dot(Vector2 p, float size, Color col, float z)
        {
            float h = size * 0.5f;
            Quad(p + new Vector2(-h, -h), p + new Vector2(h, -h), p + new Vector2(h, h), p + new Vector2(-h, h), col, z);
        }

        public void Rect(Vector2 min, Vector2 max, float width, Color col, float z)
        {
            Line(new Vector2(min.x, min.y), new Vector2(max.x, min.y), width, col, z);
            Line(new Vector2(max.x, min.y), new Vector2(max.x, max.y), width, col, z);
            Line(new Vector2(max.x, max.y), new Vector2(min.x, max.y), width, col, z);
            Line(new Vector2(min.x, max.y), new Vector2(min.x, min.y), width, col, z);
        }

        public void FillPolygon(List<Vector2> poly, Color col, float z)
        {
            if (poly == null || poly.Count < 3) return;
            var p = new List<Vector2>(poly);
            if (MeshKit.SignedArea(p) < 0) p.Reverse();
            List<int> tri = MeshKit.Triangulate(p);
            int k = v.Count;
            for (int i = 0; i < p.Count; i++) { v.Add(new Vector3(p[i].x, p[i].y, z)); c.Add(col); }
            for (int i = 0; i < tri.Count; i++) t.Add(k + tri[i]);
        }

        void Quad(Vector2 a, Vector2 b, Vector2 cc, Vector2 d, Color col, float z)
        {
            int k = v.Count;
            v.Add(new Vector3(a.x, a.y, z)); v.Add(new Vector3(b.x, b.y, z));
            v.Add(new Vector3(cc.x, cc.y, z)); v.Add(new Vector3(d.x, d.y, z));
            for (int i = 0; i < 4; i++) c.Add(col);
            t.Add(k); t.Add(k + 1); t.Add(k + 2); t.Add(k); t.Add(k + 2); t.Add(k + 3);
        }

        public void Fill(Mesh m)
        {
            m.Clear();
            if (v.Count > 65000) m.indexFormat = IndexFormat.UInt32;
            m.SetVertices(v);
            m.SetColors(c);
            m.SetTriangles(t, 0);
            m.RecalculateBounds();
        }
    }
}
