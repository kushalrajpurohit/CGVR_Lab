# CS4104 Car Design VR Demo (Case Study 2 – Industrial Design and Architecture)

## Install (Unity 6000.3.22f1, URP or Built-in)
1. Unzip `CS4104_CarDesignVR_UnityPackage.zip` anywhere on disk (keep the folder `com.rvu.cs4104.cardesignvr` intact).
2. Unity → **Window → Package Manager → + → Add package from disk…** → select `com.rvu.cs4104.cardesignvr/package.json`.
3. Menu bar → **CS4104 → Build Demo Scene and Play**. (Creates `Assets/CS4104_CarDesignVR_Demo.unity` and enters Play mode.)
   Alternatively: any scene → empty GameObject → Add Component → **Car Design Demo** → Play.

Tip: maximise the Game view (Shift+Space or "Play Maximized") and use a 16:9 resolution.

## Controls
| Input | Action |
|---|---|
| Left / right mouse drag | Orbit camera |
| Mouse wheel | Zoom |
| 1 – 5 or top buttons | Switch demo mode |
| W | Wireframe overlay |
| H | Hide / show the info panel (for clean screenshots) |

## Modes (map to report sections)
1. **CAD → Mesh** – 2-D side profile extruded to a B-rep body; wheels by lathe (surface of revolution); tessellation slider with chordal error; V/E/F and Euler characteristic; exploded CSG view.
2. **Transform T·R·S** – wheel rim in millimetres: S(1.5) → R_y(45°) → T(0,0,50). Shows S, R, T, the hand-multiplied M, Unity's `Matrix4x4.TRS`, their difference (0), and P' = M·P for P = (0,0,216). Toggle the wrong order S·R·T to see the translation become (53.03, 0, 53.03).
3. **Clipping 2D** – Cohen–Sutherland / Liang–Barsky line clipping (same lines as the report's worked examples) with a step trace, and Sutherland–Hodgman polygon clipping.
4. **Hidden Surfaces** – back-face culling (Off/Front/Back) with live N·V back-face count, section-plane clipping exposing magenta back faces, Z-buffer view, near/far plane sliders, view-frustum culling with a top-down observer view.
5. **Stereo VR / Collab** – left/right eye cameras (IPD slider) = the HMD's dual displays, frame time vs the 11.11 ms 90 Hz budget, stress test, Bengaluru ⇄ Detroit latency simulation.

No headset is needed: stereo is shown side-by-side. Everything is generated procedurally (no imported models).
